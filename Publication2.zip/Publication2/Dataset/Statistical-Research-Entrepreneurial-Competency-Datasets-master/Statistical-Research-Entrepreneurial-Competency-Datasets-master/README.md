# Statistical-Research-Entrepreneurial-Competency-Datasets

These datasets are part of a research project titled, 
"Predicting and Improving Entrepreneurial Competency in University Students using Machine Learning Algorithms". These data files are used in the project, and the project owners have decided to make the datasets open-source to fuel further analysis. 
You're free to use the datasets. Crediting isn't required, but would be appreciated.

The supporting research paper using this dataset has been presented and published in the proceedings of Confluence 2020: 10th International Conference on Cloud Computing, Data Science & Engineering, an IEEE sponsored conference hosted by Amity University, Uttar Pradesh.
